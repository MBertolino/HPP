echo Hej hej
echo 
echo Hej igen
