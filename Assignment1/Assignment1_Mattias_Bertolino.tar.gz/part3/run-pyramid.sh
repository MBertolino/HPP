./pyramid 3
./pyramid 5
./pyramid 7
./pyramid 9
./pyramid 11
